
public class StudentApp {

	public static void main(String[] args) {
		
		// max amount of students
		final int MAX_COUNT = 20;
		// student count
		int totalStudents = 1;
		// student array
		Student students [] = new Student [MAX_COUNT];
		View user = new View();
		
		// get total points for class and catagories		
		Student.labPointsPS = 200; // user.getLabPointsPossible();
		Student.projectPointsPS = 400;// user.getProjectPointsPossible();
		Student.examPointsPS = 150; // user.getExamPointsPossible();
		Student.zyBookPointsPS = 200; // user.getzyBookPointsPossible();
		Student.finalPointsPS = 100; // user.getFxamPointsPossible();

		for (int i = 0; i < MAX_COUNT; i++) {
			// initialze a student
			students[i] = new Student(user.getName(),
										  user.getLast(),
										  user.getWID(),
										  user.getStudentsLab(), 
										  user.getStudentsProjects(),
										  user.getStudentsExams(),
										  user.getStudentsZyBooks(),
										  user.getStudentsFExam());

			if (user.promptForStudent(i + 1) == 'N') {
				break;
			}
			else { 
				totalStudents++; 
			}
		}
		
		// print off students
		user.printAllStudents(totalStudents, students);
		
	}

}
