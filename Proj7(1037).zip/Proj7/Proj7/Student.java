
public class Student {
	private String firstName;
	private String lastName;
	private String WID;
	private double labScore;
	private double projectsScore;
	private double examsScore;
	private double zyBooksScore;
	private double finalExamScore;
	private double overallScore;
	
	// hold total points possible for class
	public static double labPointsPS;
	public static double projectPointsPS;
	public static double examPointsPS;
	public static double zyBookPointsPS;
	public static double finalPointsPS;
	
	// weights of each category
	private static final double labWeight = .15;
	private static final double projectWeight = .15;
	private static final double examWeight = .30; 
	private static final double zyBookWeight = .10;
	private static final double finalWeight = .30;
	
	// grade scale for class
	private final double GRADE_A = 89.5;
	private final double GRADE_B = 79.5;
	private final double GRADE_C = 68.5;
	private final double GRADE_D = 58.5;
	
	// hold grade letter of student
	private char finGrade;
	
	// construct
	public Student(String firstName, String lastName, String WID, 
				   double labScore, double projectsScore, double examsScore,
				   double zyBooksScore, double finalExamScore) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.WID = WID;
		this.labScore = labScore;
		this.projectsScore = projectsScore;
		this.examsScore = examsScore;
		this.zyBooksScore = zyBooksScore;
		this.finalExamScore = finalExamScore;
	}
	
	// default construct
	public Student() {
		this.firstName = "no name entered";
		this.lastName = "no name entered";
		this.WID = "no WID";
		this.labScore = 0.0;
		this.projectsScore = 0.0;
		this.examsScore = 0.0;
		this.zyBooksScore = 0.0;
		this.finalExamScore = 0.0;
		this.overallScore = 0.0;
	}
	
	// display student information
	public String toString() {
		finalGrade();
		// print student name Last, First
		StringBuilder student = new StringBuilder();
		student.append(lastName + ", " + firstName + "\n");
		student.append("WID: " + WID + "\n");
		
		// need to format overallScore in calcOverAllPercentScore()
		
		student.append("overallPct: " + String.format("%.2f", overallScore) + "\n");	
		student.append("Final Grade: " + finGrade);
		return student.toString();
	}
	
	// need to find percentage, then call calc overall
	// think back to how lang explained it

	// return adj amount of points for each catagory
	public static double labAdj() {
		return totalPointsPS * labWeight;
	}
	
	public static double projAdj() {
		return totalPointsPS * projectWeight;
	}
	
	public static double examAdj() {
		return totalPointsPS * examWeight;
	}
	
	public static double zyBookAdj() {
		return totalPointsPS * zyBookWeight;
	}
	
	public static double finalAdj() {
		return totalPointsPS * finalWeight;
	}
	
	// calculate percentage of catagory for each student
	public double studentAdjTotal() {
		return labAdj() * (this.labScore / labPointsPS) +
			   projAdj() * (this.projectsScore / projectPointsPS) +
			   examAdj() * (this.examsScore / examPointsPS) +
			   zyBookAdj() * (this.zyBooksScore / zyBookPointsPS) +
			   finalAdj() * (this.finalExamScore / finalPointsPS);
	}
	
	// find overallScore 
	private void calcOverAllPercentScore() {
		overallScore =  (studentAdjTotal() / totalPointsPS) * 100;
	}
	
	// find final grade for student
	private void finalGrade() {
		calcOverAllPercentScore();
		
		if (overallScore >= GRADE_A) {
			finGrade = 'A';
		}
		else if (overallScore >= GRADE_B) {
			finGrade = 'B';
		}
		else if (overallScore >= GRADE_C) {
			finGrade = 'C';
		}
		else if (overallScore > GRADE_D) {
			finGrade = 'D';
		}
		else {finGrade = 'F';}
	}
	
	
}
