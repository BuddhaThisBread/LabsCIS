import java.util.Scanner;
import java.util.StringTokenizer;

public class FractionApp {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		String hold = scnr.nextLine();
		StringTokenizer fract = new StringTokenizer(hold);
		while(fract.hasMoreTokens()) {
			System.out.println(fract.nextToken());
			System.out.println("Count: " + fract.countTokens());
		}
		
	}

}
