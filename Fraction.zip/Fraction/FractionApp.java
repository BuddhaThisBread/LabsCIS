
public class FractionApp {

	public static void main(String[] args) {
		Fraction fraction1 = new Fraction(1, 4);
		System.out.print(fraction1.toString());
	}

}
