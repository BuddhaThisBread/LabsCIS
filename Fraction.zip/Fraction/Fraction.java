/*
 	
 */
public class Fraction {
	private int Numerator;
	private int Denominator;
	
	public Fraction(int Numerator, int Denominator) {
		this.Numerator = Numerator;
		this.Denominator = Denominator;
	}
	
	public Fraction(int Numerator) {
		this.Numerator = Numerator;
		this.Denominator = 1;
	}
	
	public Fraction() {
		this.Numerator = 1;
		this.Denominator = 1;
	}
	
	public String toString() {
		StringBuilder fractize = new StringBuilder();
		String num, den;
		
		num = Integer.toString(Numerator);
		den = Integer.toString(Denominator);
		fractize.append(num + "/" + den);
		return fractize.toString();
	}
}
