
import java.util.Random;
import java.util.Scanner;

public class LabTwo {

	public static void main(String[] args) {
		Random randGen = new Random();
		Scanner scnr = new Scanner(System.in);
		
		// Constants for upper and lower bounds for user input
		final int UPPER_BOUND = 99;
		final int LOWER_BOUND = 0;
		
		// generate 5 random numbers within upper and lower bounds
		int rand1 = randGen.nextInt(UPPER_BOUND) + 1;
		int rand2 = randGen.nextInt(UPPER_BOUND) + 1;
		int rand3= randGen.nextInt(UPPER_BOUND) + 1;
		int rand4= randGen.nextInt(UPPER_BOUND) + 1;
		int rand5= randGen.nextInt(UPPER_BOUND) + 1;
		int powerBall = randGen.nextInt(UPPER_BOUND) + 1;	
		
		// display random numbers and PB
		System.out.format("Tonights given numbers and powerball: %d, %d, %d, %d, %d and PB %d\n\n", rand1, rand2, rand3, rand4, rand5, powerBall);
		
		// have user input their five numbers, also check if their input is between set bounds 
		System.out.print("Please enter your 1st number: ");
		int userInput1 = Integer.parseInt(scnr.nextLine());
		if ((userInput1 <= LOWER_BOUND) || (userInput1 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput1 = Integer.parseInt(scnr.nextLine());
		}
		
		System.out.print("Please enter your 2nd number: ");
		int userInput2 = Integer.parseInt(scnr.nextLine());
		if ((userInput2 <= LOWER_BOUND) || (userInput2 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput2 = Integer.parseInt(scnr.nextLine());
		}
		
		System.out.print("Please enter your 3rd number: ");
		int userInput3 = Integer.parseInt(scnr.nextLine());
		if ((userInput3 <= LOWER_BOUND) || (userInput3 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput3 = Integer.parseInt(scnr.nextLine());
		}
		
		System.out.print("Please enter your 4th number: ");
		int userInput4 = Integer.parseInt(scnr.nextLine());
		if ((userInput4 <= LOWER_BOUND) || (userInput4 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput4 = Integer.parseInt(scnr.nextLine());
		}
		
		System.out.print("Please enter your 5th number: ");
		int userInput5 = Integer.parseInt(scnr.nextLine());
		if ((userInput5 <= LOWER_BOUND) || (userInput5 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput5 = Integer.parseInt(scnr.nextLine());
		}
		
		System.out.print("Please enter your power ball number: ");
		int userInput6 = Integer.parseInt(scnr.nextLine());
		if ((userInput6 <= LOWER_BOUND) || (userInput5 >= UPPER_BOUND + 1)) {
			System.out.print("The number has to be between 1 and 99. Please re-enter your number: ");
			userInput6 = Integer.parseInt(scnr.nextLine());
		}
		
		// find match between userInput and all given numbers by comparing each user number with each random number
		boolean allFiveMatch = ((userInput1 == rand1) || (userInput1 == rand2) || (userInput1 == rand3) || (userInput1 == rand4) || (userInput1 == rand5) &&
								(userInput2 == rand1) || (userInput2 == rand2) || (userInput2 == rand3) || (userInput2 == rand4) || (userInput2 == rand5) &&
								(userInput3 == rand1) || (userInput3 == rand2) || (userInput3 == rand3) || (userInput3 == rand4) || (userInput3 == rand5) &&
								(userInput4 == rand1) || (userInput4 == rand2) || (userInput4 == rand3) || (userInput4 == rand4) || (userInput4 == rand5) &&
								(userInput5 == rand1) || (userInput5 == rand2) || (userInput5 == rand3) || (userInput5 == rand4) || (userInput5 == rand5));
		
		// find match between power ball number and all of userinputs 
		boolean power = ((userInput1 == powerBall) || (userInput2 == powerBall) || (userInput3 == powerBall) || (userInput4 == powerBall) || (userInput5 == powerBall) || (userInput6 == powerBall));
		
		// determine if user has just 5 matches, all matches (including powerball), just a power ball match or nothing at all 
		if ((allFiveMatch && !power)) {
			System.out.print("All five numbers match (but not the powerball). You've won 1 million dollars!");
		} else if ((allFiveMatch && power)) {
			System.out.print("All numbers plus the Powerball match! You've won the grand prize of 6.5 million dollars!");
		} else if (!allFiveMatch && power) {
			System.out.print("Your Powerball number matches! You've won $1,000 dollars!");
		} else {
			System.out.print("None of your numbers are winners. Try again soon!");
		}
		
	}

}
