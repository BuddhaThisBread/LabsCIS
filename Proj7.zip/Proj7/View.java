import java.util.Scanner;

public class View {
	private Scanner scnr;
	
	// get points, called below
	private int getPoints() {
		return Integer.parseInt(scnr.nextLine());
	}
	
	public View() {
		scnr = new Scanner(System.in);
	}

	// get name, WID and scores for each student
	public String getName() {
		System.out.print("\nEnter the student's first name: ");
		return scnr.nextLine();
	}
	
	// get last name
	public String getLast() {
		System.out.print("Enter the student's last name: ");
		return scnr.nextLine();
	}
	
	// get WID
	public String getWID() {
		System.out.print("Enter the student's WID: ");
		return scnr.nextLine();
	}
	
	// ask for points for each catagory
	public int getLabPointsPossible () {
			System.out.print("Please enter the total number " +
							 "of points possible for Labs: ");
		
		return Integer.parseInt(scnr.nextLine());
	}
	
	
	// project points pos
	public int getProjectPointsPossible () {
		System.out.print("Please enter the total number " +
						 "of points possible for Projects: ");
	
		return Integer.parseInt(scnr.nextLine());
	}
	// exam points ps
	public int getExamPointsPossible () {
		System.out.print("Please enter the total number " +
						 "of points possible for Exams: ");
		
		return Integer.parseInt(scnr.nextLine());
	}
	// zybook points ps
	public int getzyBookPointsPossible () {
		System.out.print("Please enter the total number " +
						 "of points possible for zyBooks: ");
		
		return Integer.parseInt(scnr.nextLine());
	}
	// final exam points ps
	public int getFxamPointsPossible () {
		System.out.print("Please enter the total number " +
						 "of points possible for Final Exam: ");
		
		return Integer.parseInt(scnr.nextLine());
	}
	
	// get scores for student
	public double getStudentsLab() {
		System.out.print("\nEnter the student's total Lab score: ");
		return Double.parseDouble(scnr.nextLine());
	}
	
	public double getStudentsProjects() {
		System.out.print("Enter the student's total Projects score: ");
		return Double.parseDouble(scnr.nextLine());
	}
	
	public double getStudentsExams() {
		System.out.print("Enter the student's total Exams score: ");
		return Double.parseDouble(scnr.nextLine());
	}
	
	public double getStudentsZyBooks() {
		System.out.print("Enter the student's total zyBooks score: ");
		return Double.parseDouble(scnr.nextLine());
	}
	
	public double getStudentsFExam() {
		System.out.print("Enter the student's Final Exam score: ");
		return Double.parseDouble(scnr.nextLine());
	}
	
	// show student entered, ask for another student
	public char promptForStudent(int counter) {
		System.out.println();
		System.out.println(Integer.toString(counter) + " Student(s) entered");
		System.out.print("Enter another Student? (Y/N): ");
		return scnr.nextLine().charAt(0);
	}
}

	
	
	
	
	
	
	
	
	
	
	
	