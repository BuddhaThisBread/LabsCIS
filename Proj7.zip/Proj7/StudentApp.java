
public class StudentApp {

	public static void main(String[] args) {
		
		// max amount of students
		final int MAX_COUNT = 20;
		// student count
		int totalStudents = 1;
		// student array
		Student students [] = new Student [MAX_COUNT];
		View user = new View();
		
		// get total points for class and catagories
		Student.labPointsPS = user.getLabPointsPossible();
		Student.projectPointsPS = user.getProjectPointsPossible();
		Student.examPointsPS = user.getExamPointsPossible();
		Student.zyBookPointsPS = user.getzyBookPointsPossible();
		Student.finalPointsPS = user.getFxamPointsPossible();
		
		for (int i = 0; i < MAX_COUNT; i++) {
			// initialze a student
			Student student = new Student(user.getName(),
										  user.getLast(),
										  user.getWID(),
										  user.getStudentsLab(), 
										  user.getStudentsProjects(),
										  user.getStudentsExams(),
										  user.getStudentsZyBooks(),
										  user.getStudentsFExam());

			if (user.promptForStudent(i + 1) == 'N') {
				students[i] = student;
				break;
			}
			else { 
				students[i] = student;
				totalStudents++; 
			}
		}
		
		// print off students
		for (int i = 0; i < totalStudents; i++) {
System.out.println("here");
			students[i].toString();
		}
		
	}

}
