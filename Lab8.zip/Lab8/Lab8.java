/*
 	<Lab8.java>
 	<Favian Lininger / C / Friday - 330:530>
 	
 	<Creates two lines when no arguments from user present. Prints out slope 
 	<intercept formula for lines created and determines if they intersect or not
 	
 	<If user enters 2 points via command line "x1 y1 x2 y2", program creats line
 	<and checks if initial lines are the same as users, same points/slope
 	
*/

import java.util.*;

public class Lab8 {
 public static void main(String[] args) {
	Point[] points = new Point[4];
	boolean intersection;
	
	if (args.length > 0 && args.length != 4) {
		System.out.print("Usage: java Lab8 int x1 int y1 int x2 int y2"); // check if graders entered 
		return;															  // right amount of arguments lol
	}
	
	System.out.println("\n***To run extra credit portion, "
			 + "type (x,y) values \"java Lab8 x1 y1 x2 y2\" ***\n\n"); // warn graders for checking 
	
	points[0] = new Point(1,1); // given points 
	points[1] = new Point(3,3);
	points[2] = new Point(0,4);
	points[3] = new Point(1,6);

	// create a Line object with the first two points in the array.  Call it line1
	Line line1 = new Line(points[0], points[1]);
			
	// create a Line object with the second two points in the array.  Call it line2.
	Line line2 = new Line(points[2], points[3]);
	
	// display line1 by calling toString
	System.out.println(line1.toString());
	
	// display line2 by calling toString
	System.out.println(line2.toString());
	
	// call 'intersects' method to see if line1 intersects line2.  
	// ...store the result in a boolean variable.
	intersection = line1.intersects(line2);

	// if the result is true, display "Lines intersect"
	// ...if the result is not true, print "Lines do NOT intersect"
	if (intersection) {
		System.out.print("Lines intersect");
	}
	else if (!intersection) {
		System.out.print("Lines do NOT intersect");
	}
	
	if (args.length == 4) {
		Point userFirst = new Point(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
		Point userSecond = new Point(Integer.parseInt(args[2]), Integer.parseInt(args[3]));
		Line test = new Line(userFirst, userSecond);
	
		String equalsTo;
		if (test.equals(line1)) {
			equalsTo = "equals to line 1";
		}
		else if(test.equals(line2)) {
			equalsTo = "equals to line 2";
		}
		else { 
			equalsTo = "does not equal line 1 or 2"; 
		}
		System.out.print("\nTest Line:\n" +
						 "Enter in x1-value: " +
						 userFirst.getX() + "\n" +
						 "Enter in a y1-value: " +
						 userFirst.getY() + "\n" +
						 "Enter in a x2-value: " +
						 userSecond.getX() + "\n" +
						 "Enter in a y2-value: " +
						 userSecond.getY() + "\n" +
						 test.toString() + "\n" +
						 "test line " +
						 equalsTo);
	}
	} // end main
} // end class