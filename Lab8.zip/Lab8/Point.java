/*
 	<Lab8.java>
 	<Favian Lininger / C / Friday - 330:530>
 	
 	<Point is an object with a x and y value of type int
 	
 	<program checks if a pair of different points have same values
 	<also has getters for x and y values of Point object
 	
*/

public class Point {
	private int x;
	private int y;

	public Point(int newX, int newY) {
		x = newX;
		y = newY;
	} // end 2-arg constructor
	
	public boolean equals (Point another) { 
		return this.getY() == another.getY() && 
			   this.getX() == another.getX();  
	} // check if points are exact 
	
	public int getX() {
		return x;
	} // end getX()

	public int getY() {
		return y;
	} // end getY()
	
} // end class