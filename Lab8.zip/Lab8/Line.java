/*
 	<Line.java>
 	<Favian Lininger / C / Friday - 330:530>
 	
 	<Line object is constructed with 2 Point objects. Program then
 	<determines the slope and y_intercept with given Points objects
 	
 	<toString() prints out slope intercept formula for line
 	<intersects(line) checks if another line has different slope
 	<or if lines have same slope and y_intercept
 	
*/


public class Line {
	private Point p1;
	private Point p2;
	private double slope;
	private double y_intercept;

	public Line(Point first, Point second) {
		p1 = first;
		p2 = second;
		slope = ((double)second.getY() - first.getY()) / (second.getX() - first.getX());
		y_intercept = first.getY() - slope * first.getX();
	} // end 2-arg constructor

	public String toString() {
		return String.format("Y = %.1fx + %.1f", slope, y_intercept); // print y = mx + b
	} // end toString()

	public boolean intersects(Line another) {
		if (this.slope != another.slope) { // same line check
			return true;
		}
		else  if ((this.slope == another.slope) && (this.y_intercept == another.y_intercept)) { // if different slopes, intersection occurs
			return true;
		}
		else {
			return false;
		}	
	} // end intersects()
	
	public boolean equals (Line another) {
		if ((this.p1.equals(another.p1)) && 
			(this.p2.equals(another.p2))) { // if points on first line are same on second line
			return true;
		}
		else if ((this.p1.equals(another.p2)) && 
				 (this.p2.equals(another.p1))){ // same check, case where points on second line
			return true;						// are "inversed", defined from right to left 
		}
		else { return false;}
}

} // end class